<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoleUielement extends Model
{
    //
    protected $table = "role_uielement";
}
