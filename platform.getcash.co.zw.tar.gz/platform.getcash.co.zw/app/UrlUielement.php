<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UrlUielement extends Model
{
    protected $table = 'url_uielement';

}
