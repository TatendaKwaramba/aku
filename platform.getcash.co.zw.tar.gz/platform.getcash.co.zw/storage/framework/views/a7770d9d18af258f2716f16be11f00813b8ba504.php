<!DOCTYPE html>
<html>
<head>
    <title><?php $__env->startSection('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('/css/app.css')); ?>">
</head>
<body>
<div class="row">
    <strong class="jumbotron"><?php echo e(config('app.name')); ?></strong>
</div>

<p class="row">Hello <?php echo e($user->name); ?></p>
<p class="row">
    <?php echo $__env->yieldContent('tr1'); ?>
</p>
<p class="row">
    <?php echo $__env->yieldContent('tr2'); ?>
</p>
<p class="row">
    <?php echo $__env->yieldContent('tr3'); ?>
</p>

<p>Regards, </p>
<p><?php echo e(config('app.name')); ?></p><br>
<div class="row">
    <center>
        <small>©<?php echo e(date("Y")); ?> <?php echo e(config('app.organisation')); ?></small>
    </center>
</div>
</body>
</html><?php /**PATH /var/www/platform.getcash.co.zw/resources/views/mail/layout.blade.php ENDPATH**/ ?>