<?php $__env->startSection('tr1'); ?>
    Your account on GetCash platform has been blocked following 3 unsuccessful login attempts.
    Please contact admin for assistance.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tr2'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tr3'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mail.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>