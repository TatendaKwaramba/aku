<?php $__env->startSection('tr1'); ?>
    Your account on GetCash platform has been activated.
    Your may login using the credentials you created during sign-up.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tr2'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tr3'); ?>
    <p>If you did not register on our platform please contact <code>it@getcash.co.zw</code>. Someone may have illegally used your email address.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mail.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>