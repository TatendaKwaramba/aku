<?php $__env->startSection('tr1'); ?>
    You are receiving this email because this email address has been used on <?php echo e(config('app.name')); ?>.
    <p>An account has been created and is awaiting approval by the system admin</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tr2'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('tr3'); ?>
    <p>If you did not register on our platform please contact <code>it@chkwama.co.zw</code>. Someone may have illegally used your email address.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mail.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/platform.getcash.co.zw/resources/views/mail/account/created.blade.php ENDPATH**/ ?>